# Glitch QA Website

Marketing website for Glitch QA, an end-to-end software testing company. Built with React, Vite and React Router.

## Run

```bash
npm install
npm run dev      # local dev server, normally http://localhost:5173
npm run build    # production build in dist/
npm run preview  # serve the production build locally
```

## Where things live

- `src/data.js`: all site content. That covers services, partnership models, why-us cards, tools, domains, customers, contact details and legal text.
- `public/images/`: all images, grouped by section (`brand`, `services`, `partnership`, `why`, `tools`, `domains`, `customers`).
- `src/pages/`: the Home, Contact, Privacy/Terms (`LegalPage`) and 404 pages.
- `src/components/`: shared pieces such as the header, footer, flip card, logo tile and email form.
- `src/styles.css`: all styles. Colours come from `src/theme.css`.
- `src/components/illustrations/`: the hero illustration and the 10x graphic, drawn inline so they follow the theme.

## Colours

- The site uses one maroon and charcoal palette. Every colour is a token in `src/theme.css`, so changing the palette means editing that one file.
- If you change `--accent`, also update the `theme-color` meta tag in `index.html` (the phone browser bar colour).

## Before launch

- Have the Privacy Policy and Terms (`legal` in `src/data.js`) reviewed.
- The contact forms have no backend. They open the visitor's email app with a pre-filled message to `CONTACT.email`.

## Deploying

The site uses real URLs (`/contact`, `/privacy`, `/terms`). The host must serve `index.html` for unknown paths, otherwise refreshing those pages returns 404:

- **Netlify:** add `public/_redirects` containing `/* /index.html 200`.
- **Vercel:** add `vercel.json` with `{ "rewrites": [{ "source": "/(.*)", "destination": "/" }] }`.
- **Sub-folder hosting** (e.g. GitHub Pages at `/repo-name/`): set `base` in a Vite config. Image paths and routes already follow `import.meta.env.BASE_URL`.

## Image credits

- Hero illustration: [unDraw](https://undraw.co), free licence.
- Line icons for Feature & Workflow, UI/UX, Regression, UAT, Prod, the partnership models, and the Healthcare, E-Commerce, Logistics, Educational and Banking domains: built from [Tabler Icons](https://tabler.io/icons) (MIT).
- Logo, customer logos, tool logos and the remaining pictures come from the Glitch QA website blueprint supplied by the client.
