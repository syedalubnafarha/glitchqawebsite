import React, { useState } from "react";
import { openEmail } from "../lib/mailto";

export default function EmailForm({dark=false}){
  const [email,setEmail]=useState("");
  const [sent,setSent]=useState(false);
  const submit=e=>{
    e.preventDefault();
    openEmail("Talk to an expert", ["Hi Glitch QA,","","I'd like to schedule a call to talk about testing for our product.","",`My work email: ${email}`]);
    setSent(true);
  };
  return <form className={dark?"email-form dark":"email-form"} onSubmit={submit}>
    <input value={email} onChange={e=>{setEmail(e.target.value);setSent(false)}} placeholder="Enter a business email" type="email" name="email" autoComplete="email" aria-label="Business email" required />
    <button>{sent?"Thanks!":"Talk to an Expert"}</button>
  </form>
}
