import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";

// React Router does not scroll on navigation: go to the #section if the URL has one, else to the top.
export default function ScrollManager(){
  const { pathname, hash, key } = useLocation();
  const prevPath = useRef(pathname);
  useEffect(()=>{
    const samePage = prevPath.current === pathname;
    prevPath.current = pathname;
    const target = hash && document.getElementById(decodeURIComponent(hash.slice(1)));
    if(target) target.scrollIntoView({behavior: samePage ? "smooth" : "instant"});
    else window.scrollTo({top:0, behavior:"instant"});
  },[pathname,hash,key]);
  return null;
}
