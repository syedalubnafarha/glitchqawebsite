import React from "react";

// A bordered tile with an image and optional caption; used for tools, domains and customer logos.
export default function LogoTile({name,image,caption=true}){
  return <div className={caption?"logo-tile":"logo-tile logo-only"}>
    <img src={image} alt={caption?"":name} loading="lazy" />
    {caption&&<span>{name}</span>}
  </div>
}
