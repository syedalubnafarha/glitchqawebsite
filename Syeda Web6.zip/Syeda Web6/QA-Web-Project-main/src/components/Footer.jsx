import React from "react";
import { Link } from "react-router-dom";
import { IMG, CONTACT, navLinks } from "../data";

export default function Footer(){
  return <footer>
    <div className="container footer-grid">
      <div className="footer-brand">
        <Link className="brand" to="/" aria-label="Glitch QA home"><img src={IMG+"brand/glitch-qa-logo.webp"} alt="Glitch QA — Zero glitches. Infinite trust" width="640" height="199" loading="lazy" /></Link>
        <p>Ship faster. Test smarter. Grow with Glitch QA.</p>
      </div>
      <div><h4>Explore</h4>{navLinks.map(([label,id])=><Link key={id} to={"/#"+id}>{label}</Link>)}</div>
      <div><h4>Company</h4><Link to="/contact">Contact us</Link><Link to="/privacy">Privacy Policy</Link><Link to="/terms">Terms of Service</Link></div>
      <div><h4>Contact</h4><a href={"mailto:"+CONTACT.email}>{CONTACT.email}</a><a href={"tel:"+CONTACT.phoneHref}>{CONTACT.phone}</a></div>
    </div>
    <div className="footer-bottom container"><span>© {new Date().getFullYear()} Glitch QA. All rights reserved.</span><span><Link to="/privacy">Privacy</Link> · <Link to="/terms">Terms</Link></span></div>
  </footer>
}
