import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { IMG, navLinks } from "../data";

export default function Header(){
  const [open,setOpen] = useState(false);
  const location = useLocation();
  useEffect(()=>setOpen(false),[location.key]);
  return <header className="header">
    <div className="nav container">
      <Link className="brand" to="/" aria-label="Glitch QA home"><img src={IMG+"brand/glitch-qa-logo.webp"} alt="Glitch QA — Zero glitches. Infinite trust" width="640" height="199" /></Link>
      <nav id="site-nav" className={open?"navlinks open":"navlinks"} aria-label="Main">
        {navLinks.map(([label,id])=><Link key={id} to={"/#"+id}>{label}</Link>)}
        <Link className="nav-menu-cta" to="/contact">Talk to Us</Link>
      </nav>
      <Link className="nav-cta" to="/contact">Talk to Us</Link>
      <button className="hamburger" onClick={()=>setOpen(!open)} aria-label={open?"Close menu":"Open menu"} aria-expanded={open} aria-controls="site-nav">{open?"×":"☰"}</button>
    </div>
  </header>
}
