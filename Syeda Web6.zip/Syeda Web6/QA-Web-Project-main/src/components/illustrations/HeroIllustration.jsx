import React from "react";
// unDraw "bug fixing" (https://undraw.co). Its accent is currentColor, so inlining it lets
// the theme's --accent colour it (set via `color` on .hero-illustration).
import svg from "../../assets/illustrations/bug-fixing.svg?raw";

export default function HeroIllustration(){
  return <div className="hero-illustration" role="img" aria-label="A tester fixing a bug on a monitor" dangerouslySetInnerHTML={{__html:svg}} />
}
