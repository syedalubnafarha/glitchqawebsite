import React from "react";

// "10x" card picture for "Ship Software 10X Faster". Inline so its colours follow the theme tokens.
export default function TenXGraphic(){
  const text = {x:240,y:215,textAnchor:"middle",fontFamily:"Inter, Arial, sans-serif",fontWeight:900,fontSize:170,letterSpacing:-8};
  return <svg viewBox="0 0 480 320" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <defs><linearGradient id="tenx-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style={{stopColor:"var(--tenx-top)"}}/><stop offset="1" style={{stopColor:"var(--accent)"}}/></linearGradient></defs>
    <rect width="480" height="320" fill="#fff"/>
    <text {...text} style={{fill:"var(--tenx-shadow)"}} opacity=".18" transform="translate(8 10)">10x</text>
    <text {...text} fill="url(#tenx-fill)">10x</text>
  </svg>
}
