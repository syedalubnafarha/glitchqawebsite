import React from "react";

// `title` may contain <span> for the purple highlighted words.
export default function SectionHead({kicker,title,sub}){
  return <div className="section-head"><span className="kicker">{kicker}</span><h2>{title}</h2>{sub&&<p>{sub}</p>}</div>
}
