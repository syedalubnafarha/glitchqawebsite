import React, { useState } from "react";

// Hover flips on mouse devices; tap flips on touch; Enter / Space toggle. A mouse click is ignored so a card can't stay flipped after the pointer leaves.
// `image` is an image URL, or a component for artwork that follows the theme colours.
export default function FlipCard({image:Image,title,tagline,text}){
  const [flipped,setFlipped]=useState(false);
  return <button type="button" className={flipped?"flip-card flipped":"flip-card"} aria-pressed={flipped} onClick={e=>{if(e.detail>0&&!flipped&&matchMedia("(hover:hover)").matches)return;setFlipped(!flipped)}}>
    <span className="flip-inner">
      <span className="flip-face flip-front" aria-hidden={flipped}>
        <span className="flip-media">{typeof Image==="string"?<img src={Image} alt="" loading="lazy" />:<Image/>}</span>
        <span className="flip-title">{title}</span>
      </span>
      <span className="flip-face flip-back">
        <span className="flip-title">{title}</span>
        {tagline&&<span className="flip-tagline">{tagline}</span>}
        <span className="flip-text">{text}</span>
      </span>
    </span>
  </button>
}
