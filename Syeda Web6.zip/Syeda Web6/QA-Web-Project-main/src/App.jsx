import React from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import ScrollManager from "./components/ScrollManager";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import LegalPage from "./pages/LegalPage";
import NotFound from "./pages/NotFound";

export default function App(){
 return <>
  <ScrollManager/>
  <Header/>
  <main>
   <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/contact" element={<Contact/>}/>
    <Route path="/privacy" element={<LegalPage doc="privacy"/>}/>
    <Route path="/terms" element={<LegalPage doc="terms"/>}/>
    <Route path="*" element={<NotFound/>}/>
   </Routes>
  </main>
  <Footer/>
  <button className="top-btn" onClick={()=>window.scrollTo({top:0,behavior:"smooth"})} aria-label="Back to top">↑</button>
 </>
}
