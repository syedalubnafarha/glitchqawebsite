// All site content lives here. Images are served from /public/images.
import TenXGraphic from "./components/illustrations/TenXGraphic";

export const IMG = import.meta.env.BASE_URL + "images/";

export const CONTACT = { email: "info@glitchqa.com", phone: "+91 73863 97257", phoneHref: "+917386397257" };

// [label, section id on the home page]
export const navLinks = [["Our Services","services"],["Partnership Model","partnership"],["Why Glitch QA","why-us"],["Our Customers","customers"]];

export const heroChips = ["Automation","AI Quality","Performance","Accessibility"];

export const services = [
  { title: "Discovery-Driven Testing", image: IMG+"services/discovery-driven.webp", text: "Reveal what scripted tests miss by exploring your product with real-world curiosity, intuition, and user behavior." },
  { title: "Automated Testing", image: IMG+"services/automated.webp", text: "Our proven testing methodologies help you save valuable time and reduce costs." },
  { title: "Feature and Workflow Testing", image: IMG+"services/feature-workflow.svg", text: "Make every feature work flawlessly and every user journey flow naturally with functional testing that uncovers issues before they reach your customers." },
  { title: "Device and Browser Testing", image: IMG+"services/device-browser.webp", text: "Scale your product confidently across devices, platforms, and capabilities." },
  { title: "AI Quality Testing", image: IMG+"services/ai-quality.webp", text: "Build trustworthy AI with rigorous testing that evaluates model performance, data quality, safety, and resilience against unexpected scenarios." },
  { title: "Performance Optimization", image: IMG+"services/performance.webp", text: "Put your product to the test under real-world pressure. Validate speed, stability, and scalability across demanding workloads, high user volumes, and complex tasks." },
  { title: "UI/UX Testing", image: IMG+"services/ui-ux.svg", text: "We test your app through the eyes of your users, refining every interaction to create a seamless, intuitive, and engaging experience." },
  { title: "Accessibility Testing", image: IMG+"services/accessibility.webp", text: "We test your app through the needs of every user, ensuring inclusive interactions, clear navigation, and a seamless experience for people of all abilities." },
  { title: "Regression Testing", image: IMG+"services/regression.svg", text: "Protect your product from unexpected setbacks with thorough regression testing that ensures every update works seamlessly with existing functionality." },
  { title: "UAT Release Audit", image: IMG+"services/uat-release-audit.svg", text: "Validate every release with thorough UAT and release audits—ensuring your product meets expectations and is ready to go live." },
  { title: "Prod Release Audit", image: IMG+"services/prod-release-audit.svg", text: "Release with confidence through comprehensive production audits that uncover last-minute risks and ensure everything is ready for a smooth launch." }
];

export const partnership = [
  { title: "Ownership Framework", image: IMG+"partnership/ownership-framework.svg", tagline: "You build. You grow. We own the quality.", text: "From QA strategy and test execution to automation and release readiness, our team takes care of the entire quality journey—so your team can stay focused on the product, your customers, and what comes next." },
  { title: "Effortless Testing", image: IMG+"partnership/effortless-testing.svg", text: "We take care of QA from end to end, owning the process and the outcomes. Our team is carefully selected, managed, and led by us—so you get a dedicated QA function without the overhead. When needed, you can also be part of the team selection process." },
  { title: "Tailored Testing", image: IMG+"partnership/tailored-testing.svg", text: "Get QA built around your project, with flexible Time & Material or milestone-based engagement models. Scale your testing as your needs evolve, stay in control of scope and timelines, and get dependable results without unnecessary overhead." },
  { title: "Products in Testing", image: IMG+"partnership/products-in-testing.webp", text: "Bring proven testing products, accelerators, and frameworks into your QA setup. We help you move faster, expand test coverage, and gain clearer visibility into quality across every release." }
];

export const whyUs = [
  { title: "Ship Software 10X Faster", image: TenXGraphic, tagline: "Don’t let QA slow you down.", text: "Our smart testing framework integrates seamlessly into your workflow to cut release costs by nearly half while driving a 40% increase in productivity." },
  { title: "High-Impact Approach", image: IMG+"why/high-impact.webp", tagline: "Testing driven by product & business goals.", text: "We don't just find bugs; we think like your POs, PMs, and BAs. By deeply understanding your unique business context, we turn QA into a strategic engine for product growth." },
  { title: "Modern & Scalable", image: IMG+"why/modern-scalable.webp", tagline: "Deep contextual alignment from Day 1.", text: "We map your product, user personas, tech stack, and compliance requirements before writing a single test case. No guesswork—just precision testing tailored to your business realities." },
  { title: "Premium & Confident", image: IMG+"why/premium-confident.webp", tagline: "End-to-end quality ownership.", text: "From initial test strategy to final release sign-off, we embed into your team and take full accountability for your software’s quality. You focus on building; we’ll handle the rest." }
];

// [name, image]
export const tools = [
  ["BrowserStack", IMG+"tools/browserstack.webp"],["Lighthouse", IMG+"tools/lighthouse.webp"],["Java", IMG+"tools/java.webp"],
  ["Python", IMG+"tools/python.webp"],["Selenium", IMG+"tools/selenium.webp"],["Playwright", IMG+"tools/playwright.webp"],
  ["LLM X", IMG+"tools/llm-x.webp"],["JMeter", IMG+"tools/jmeter.webp"],["Postman", IMG+"tools/postman.webp"]
];

export const domains = [
  ["Healthcare", IMG+"domains/healthcare.svg"],["E-Commerce", IMG+"domains/e-commerce.svg"],["Telecom", IMG+"domains/telecom.webp"],
  ["Logistics", IMG+"domains/logistics.svg"],["Educational", IMG+"domains/educational.svg"],["Enterprise", IMG+"domains/enterprise.webp"],["Banking", IMG+"domains/banking.svg"],
  ["Beauty", IMG+"domains/beauty.webp"]
];

export const customers = [
  ["bsharp", IMG+"customers/bsharp.webp"],["Glue Plus", IMG+"customers/glue-plus.webp"],["Faces Canada", IMG+"customers/faces-canada.webp"],
  ["Wazzam", IMG+"customers/wazzam.webp"],["TravelPoint", IMG+"customers/travelpoint.webp"],["Colourdreamz", IMG+"customers/colourdreamz.webp"],
  ["YumWeb", IMG+"customers/yumweb.webp"],["Infrascape", IMG+"customers/infrascape.webp"],["Fincare", IMG+"customers/fincare.webp"]
];

// Placeholder legal copy for a static brochure site. TODO(client): have it reviewed before launch.
export const legal = {
  privacy: {
    title: "Privacy Policy",
    updated: "29 September 2026",
    intro: "This policy explains what information Glitch QA collects through this website and how we use it.",
    sections: [
      ["Information we collect", "We only collect the details you choose to send us, such as your name, work email, company and message when you contact us through this website or by email."],
      ["How we use it", "We use your details to reply to your enquiry, schedule calls you ask for, and provide the services you engage us for. We do not sell your personal information."],
      ["Sharing", "We share your information only with service providers who help us run our business (for example, our email provider), or when the law requires it."],
      ["Cookies and third parties", "This website does not use advertising or analytics cookies. Fonts are loaded from Google Fonts, which may receive your IP address as part of serving them."],
      ["Keeping your data", "We keep enquiry details only as long as needed to respond to you and manage our relationship, unless the law requires us to keep them longer."],
      ["Your choices", "You can ask us to access, correct or delete the personal information we hold about you by emailing us at the address below."]
    ]
  },
  terms: {
    title: "Terms of Service",
    updated: "29 September 2026",
    intro: "These terms apply to your use of the Glitch QA website. By using the site you agree to them.",
    sections: [
      ["Use of this website", "You may browse this website for information about Glitch QA and our services. Please do not misuse the site or try to disrupt it."],
      ["Content and trademarks", "The text, logos and design on this website belong to Glitch QA or its licensors. Customer and tool logos belong to their respective owners."],
      ["No warranty", "The information on this website is provided for general information only and may change without notice. It does not form a contract for services; any engagement is governed by a separate written agreement."],
      ["Limitation of liability", "To the extent permitted by law, Glitch QA is not liable for any loss arising from your use of this website."],
      ["Links to other sites", "This website may link to other websites. We are not responsible for their content or practices."],
      ["Changes", "We may update these terms from time to time. The date at the top of this page shows when they last changed."]
    ]
  }
};
