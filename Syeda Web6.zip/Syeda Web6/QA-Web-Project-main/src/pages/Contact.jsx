import React, { useState } from "react";
import { CONTACT, services } from "../data";
import { usePage } from "../lib/usePage";
import { openEmail } from "../lib/mailto";

const steps = ["Tell us about your product and what you want to achieve.","We get back to you to schedule a call.","We propose a testing plan built around your needs."];

export default function Contact(){
  usePage("Talk to Us");
  const [sent,setSent]=useState(false);
  const submit=e=>{
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.currentTarget));
    openEmail(`Enquiry from ${f.name}${f.company?` (${f.company})`:""}`, [
      `Name: ${f.name}`, `Work email: ${f.email}`, f.company?`Company: ${f.company}`:null, `Service of interest: ${f.service}`, "", f.message
    ]);
    setSent(true);
  };
  return <section className="page contact-page"><div className="container">
    <div className="page-head reveal"><span className="kicker">Talk to Us</span><h1>Let’s talk about your <span>product quality</span></h1><p>Share a few details and we’ll get back to you to plan the right testing approach.</p></div>
    <div className="contact-page-grid">
      <form className="enquiry-form" onSubmit={submit}>
        <label>Full name<input name="name" autoComplete="name" required /></label>
        <label>Work email<input name="email" type="email" autoComplete="email" required /></label>
        <label>Company<input name="company" autoComplete="organization" /></label>
        <label>Service of interest<select name="service" defaultValue="Not sure yet">
          <option>Not sure yet</option>{services.map(s=><option key={s.title}>{s.title}</option>)}
        </select></label>
        <label className="full">How can we help?<textarea name="message" rows="5" required placeholder="Tell us about your product, timelines and testing goals." /></label>
        <button className="full">Send enquiry</button>
        {sent&&<p className="full form-status" role="status">Your email app should open with your enquiry ready to send. If it doesn’t, email us at <a href={"mailto:"+CONTACT.email}>{CONTACT.email}</a>.</p>}
      </form>
      <aside className="contact-aside">
        <h2>Reach us directly</h2>
        <a href={"mailto:"+CONTACT.email}><small>Email</small>{CONTACT.email}</a>
        <a href={"tel:"+CONTACT.phoneHref}><small>Phone</small>{CONTACT.phone}</a>
        <h3>What happens next</h3>
        <ol>{steps.map(s=><li key={s}>{s}</li>)}</ol>
      </aside>
    </div>
  </div></section>
}
