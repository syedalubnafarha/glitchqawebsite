import React from "react";
import { CONTACT, legal } from "../data";
import { usePage } from "../lib/usePage";

// Renders the Privacy Policy or Terms of Service from `legal` in data.js.
export default function LegalPage({doc}){
  const {title,updated,intro,sections} = legal[doc];
  usePage(title);
  return <section className="page legal-page"><div className="container">
    <div className="page-head reveal"><span className="kicker">Last updated {updated}</span><h1>{title}</h1><p>{intro}</p></div>
    <div className="legal-body">
      {sections.map(([h,p])=><div key={h}><h2>{h}</h2><p>{p}</p></div>)}
      <div><h2>Contact</h2><p>Questions? Email us at <a href={"mailto:"+CONTACT.email}>{CONTACT.email}</a>.</p></div>
    </div>
  </div></section>
}
