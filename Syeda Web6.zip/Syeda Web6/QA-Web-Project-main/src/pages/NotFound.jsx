import React from "react";
import { Link } from "react-router-dom";
import { usePage } from "../lib/usePage";

export default function NotFound(){
  usePage("Page not found");
  return <section className="page not-found"><div className="container">
    <div className="page-head"><span className="kicker">404</span><h1>This page has a <span>glitch</span></h1><p>The page you’re looking for doesn’t exist or has moved.</p><Link className="nav-cta" to="/">Back to home</Link></div>
  </div></section>
}
