import React, { useState } from "react";
import { Link } from "react-router-dom";
import { heroChips, services, partnership, whyUs, tools, domains, customers } from "../data";
import { usePage } from "../lib/usePage";
import EmailForm from "../components/EmailForm";
import SectionHead from "../components/SectionHead";
import FlipCard from "../components/FlipCard";
import LogoTile from "../components/LogoTile";
import HeroIllustration from "../components/illustrations/HeroIllustration";

function Hero(){
  return <section id="top" className="hero">
    <div className="hero-glow one"></div><div className="hero-glow two"></div>
    <div className="container hero-grid">
      <div className="hero-copy reveal">
        <div className="eyebrow">Quality Assurance Testing</div>
        <h1><span>End-to-End</span> Software Testing Services</h1>
        <div className="underline"></div>
        <p>Ship faster. Test smarter. Grow with Glitch QA.</p>
        <div className="hero-form"><strong>Enter your work-email and schedule a call for priority support!</strong><EmailForm/></div>
      </div>
      <div className="hero-art">
        <div className="orbit orbit-a"></div><div className="orbit orbit-b"></div>
        <HeroIllustration/>
        {heroChips.map((c,i)=><div className={"float-chip c"+(i+1)} key={c}>{c}</div>)}
      </div>
    </div>
  </section>
}

function CardSection({id,className,kicker,title,sub,items,children}){
  return <section id={id} className={"section "+className}><div className="container">
    <SectionHead kicker={kicker} title={title} sub={sub}/>
    <div className="card-grid">{items.map(x=><FlipCard key={x.title} {...x}/>)}</div>
    {children}
  </div></section>
}

function Expertise(){
  const [tab,setTab]=useState("tools");
  const items = tab==="tools" ? tools : domains;
  return <section id="expertise" className="section expertise"><div className="container">
    <SectionHead kicker="Tools and Domains" title={<>Where <span>QA</span> Meets <span>Expertise</span></>} sub="Whatever your technology or industry, our expertise turns quality into confidence."/>
    <div className="switch">
      <button className={tab==="tools"?"active":""} aria-pressed={tab==="tools"} onClick={()=>setTab("tools")}>Tool Expertise</button>
      <button className={tab==="domains"?"active":""} aria-pressed={tab==="domains"} onClick={()=>setTab("domains")}>Domain Expertise</button>
    </div>
    <div className={"card-grid tiles "+tab} key={tab}>{items.map(([name,image])=><LogoTile key={name} name={name} image={image}/>)}</div>
  </div></section>
}

function Customers(){
  return <section id="customers" className="section customers"><div className="container">
    <SectionHead kicker="Trusted by" title={<>Our <span>Customers</span></>}/>
    <div className="card-grid tiles">{customers.map(([name,image])=><LogoTile key={name} name={name} image={image} caption={false}/>)}</div>
  </div></section>
}

function ContactBlock(){
  return <section id="get-in-touch" className="contact"><div className="container contact-inner">
    <div><span className="kicker">Ready to ship with confidence?</span><h2>Let’s make every release glitch-free</h2><p>Tell us about your product and we’ll get back to you to schedule a call.</p></div>
    <div className="contact-box"><strong>Enter your work-email and schedule a call for priority support!</strong><EmailForm dark/><small>Business email only · No spam</small><Link className="contact-link" to="/contact">Prefer to share more detail? Send a full enquiry</Link></div>
  </div></section>
}

export default function Home(){
  usePage();
  return <>
    <Hero/>
    <section id="vision" className="section vision"><div className="container vision-panel">
      <SectionHead title={<>Our <span>Vision</span></>} sub="Building the future of software quality through AI-powered intelligence and automation."/>
      <p className="vision-note">Embracing GaaS (Agentic as a Service), we aim to make testing smarter, faster and more efficient.</p>
      <div className="vision-tiles">{[
        {title:"AI-Powered",text:"AI agents write, run and maintain your tests, so coverage grows with your product.",image:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="4" y="7" width="16" height="12" rx="4"/><path d="M12 3v4M9 12v1M15 12v1"/></svg>},
        {title:"Automation",text:"Automated suites run on every build and catch regressions before your users do.",image:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/><path d="M6.5 10v4a3 3 0 0 0 3 3H14"/></svg>},
        {title:"Quality First",text:"Every release is checked for function, performance, security and accessibility.",image:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8.2-8 9-4.6-.8-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>},
      ].map(x=><FlipCard key={x.title} {...x}/>)}</div>
    </div></section>
    <CardSection id="services" className="services" items={services} kicker="Our Services"
      title={<>A <span>Complete Suite</span> of Testing Services</>} sub="A complete spectrum of testing solutions, built around your needs.">
      <div className="inline-form"><strong>Enter your work-email and schedule a call for priority support!</strong><EmailForm/></div>
    </CardSection>
    <CardSection id="partnership" className="partnership" items={partnership} kicker="Partnership Model"
      title={<>Built <span>Around Your</span> Needs</>} sub="Brilliance that fits you."/>
    <CardSection id="why-us" className="why" items={whyUs} kicker="Why Glitch QA"
      title={<><span>Why</span> Teams Trust <span>Glitch QA</span></>} sub="The Approach Behind Glitch QA"/>
    <Expertise/>
    <Customers/>
    <ContactBlock/>
  </>
}
